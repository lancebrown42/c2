﻿namespace Homework13_TrimAllFormTextboxes
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
            this.lblExtraCredit1 = new System.Windows.Forms.Label( );
            this.tabControl1 = new System.Windows.Forms.TabControl( );
            this.tabPage1 = new System.Windows.Forms.TabPage( );
            this.txtLevel6 = new System.Windows.Forms.TextBox( );
            this.tabPage2 = new System.Windows.Forms.TabPage( );
            this.txtLevel7 = new System.Windows.Forms.TextBox( );
            this.txtLevel5 = new System.Windows.Forms.TextBox( );
            this.lblExtraCredit2 = new System.Windows.Forms.Label( );
            this.panLevel2 = new System.Windows.Forms.Panel( );
            this.txtLevel2 = new System.Windows.Forms.TextBox( );
            this.panLevel1 = new System.Windows.Forms.Panel( );
            this.grbLevel2 = new System.Windows.Forms.GroupBox( );
            this.grbLevel3 = new System.Windows.Forms.GroupBox( );
            this.txtLevel3 = new System.Windows.Forms.TextBox( );
            this.grbLevel4 = new System.Windows.Forms.GroupBox( );
            this.btnShazam = new System.Windows.Forms.Button( );
            this.txtLevel4 = new System.Windows.Forms.TextBox( );
            this.txtLevel1 = new System.Windows.Forms.TextBox( );
            this.tabControl1.SuspendLayout( );
            this.tabPage1.SuspendLayout( );
            this.tabPage2.SuspendLayout( );
            this.panLevel2.SuspendLayout( );
            this.panLevel1.SuspendLayout( );
            this.grbLevel2.SuspendLayout( );
            this.grbLevel3.SuspendLayout( );
            this.grbLevel4.SuspendLayout( );
            this.SuspendLayout( );
            // 
            // lblExtraCredit1
            // 
            this.lblExtraCredit1.AutoSize = true;
            this.lblExtraCredit1.Location = new System.Drawing.Point( 20, 308 );
            this.lblExtraCredit1.Name = "lblExtraCredit1";
            this.lblExtraCredit1.Size = new System.Drawing.Size( 73, 13 );
            this.lblExtraCredit1.TabIndex = 10;
            this.lblExtraCredit1.Text = "Extra Credit 1:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add( this.tabPage1 );
            this.tabControl1.Controls.Add( this.tabPage2 );
            this.tabControl1.Location = new System.Drawing.Point( 19, 511 );
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size( 385, 118 );
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add( this.txtLevel6 );
            this.tabPage1.Location = new System.Drawing.Point( 4, 22 );
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding( 3 );
            this.tabPage1.Size = new System.Drawing.Size( 377, 92 );
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tab 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtLevel6
            // 
            this.txtLevel6.Location = new System.Drawing.Point( 13, 12 );
            this.txtLevel6.Name = "txtLevel6";
            this.txtLevel6.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel6.TabIndex = 7;
            this.txtLevel6.Text = "        Level 6         ";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add( this.txtLevel7 );
            this.tabPage2.Location = new System.Drawing.Point( 4, 22 );
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding( 3 );
            this.tabPage2.Size = new System.Drawing.Size( 377, 92 );
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tab 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtLevel7
            // 
            this.txtLevel7.Location = new System.Drawing.Point( 37, 22 );
            this.txtLevel7.Name = "txtLevel7";
            this.txtLevel7.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel7.TabIndex = 7;
            this.txtLevel7.Text = "        Level 7         ";
            // 
            // txtLevel5
            // 
            this.txtLevel5.Location = new System.Drawing.Point( 18, 18 );
            this.txtLevel5.Name = "txtLevel5";
            this.txtLevel5.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel5.TabIndex = 6;
            this.txtLevel5.Text = "        Level 5         ";
            // 
            // lblExtraCredit2
            // 
            this.lblExtraCredit2.AutoSize = true;
            this.lblExtraCredit2.Location = new System.Drawing.Point( 18, 492 );
            this.lblExtraCredit2.Name = "lblExtraCredit2";
            this.lblExtraCredit2.Size = new System.Drawing.Size( 73, 13 );
            this.lblExtraCredit2.TabIndex = 11;
            this.lblExtraCredit2.Text = "Extra Credit 2:";
            // 
            // panLevel2
            // 
            this.panLevel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLevel2.Controls.Add( this.txtLevel5 );
            this.panLevel2.Location = new System.Drawing.Point( 21, 18 );
            this.panLevel2.Name = "panLevel2";
            this.panLevel2.Size = new System.Drawing.Size( 342, 120 );
            this.panLevel2.TabIndex = 3;
            // 
            // txtLevel2
            // 
            this.txtLevel2.Location = new System.Drawing.Point( 19, 21 );
            this.txtLevel2.Name = "txtLevel2";
            this.txtLevel2.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel2.TabIndex = 4;
            this.txtLevel2.Text = "        Level 2         ";
            // 
            // panLevel1
            // 
            this.panLevel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLevel1.Controls.Add( this.panLevel2 );
            this.panLevel1.Location = new System.Drawing.Point( 19, 327 );
            this.panLevel1.Name = "panLevel1";
            this.panLevel1.Size = new System.Drawing.Size( 385, 154 );
            this.panLevel1.TabIndex = 8;
            // 
            // grbLevel2
            // 
            this.grbLevel2.Controls.Add( this.txtLevel2 );
            this.grbLevel2.Controls.Add( this.grbLevel3 );
            this.grbLevel2.Location = new System.Drawing.Point( 19, 48 );
            this.grbLevel2.Name = "grbLevel2";
            this.grbLevel2.Size = new System.Drawing.Size( 385, 242 );
            this.grbLevel2.TabIndex = 7;
            this.grbLevel2.TabStop = false;
            this.grbLevel2.Text = "Level 2";
            // 
            // grbLevel3
            // 
            this.grbLevel3.Controls.Add( this.txtLevel3 );
            this.grbLevel3.Controls.Add( this.grbLevel4 );
            this.grbLevel3.Location = new System.Drawing.Point( 19, 47 );
            this.grbLevel3.Name = "grbLevel3";
            this.grbLevel3.Size = new System.Drawing.Size( 344, 171 );
            this.grbLevel3.TabIndex = 2;
            this.grbLevel3.TabStop = false;
            this.grbLevel3.Text = "Level 3";
            // 
            // txtLevel3
            // 
            this.txtLevel3.Location = new System.Drawing.Point( 20, 19 );
            this.txtLevel3.Name = "txtLevel3";
            this.txtLevel3.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel3.TabIndex = 4;
            this.txtLevel3.Text = "        Level 3         ";
            // 
            // grbLevel4
            // 
            this.grbLevel4.Controls.Add( this.btnShazam );
            this.grbLevel4.Controls.Add( this.txtLevel4 );
            this.grbLevel4.Location = new System.Drawing.Point( 20, 47 );
            this.grbLevel4.Name = "grbLevel4";
            this.grbLevel4.Size = new System.Drawing.Size( 304, 102 );
            this.grbLevel4.TabIndex = 3;
            this.grbLevel4.TabStop = false;
            this.grbLevel4.Text = "Level 4";
            // 
            // btnShazam
            // 
            this.btnShazam.Location = new System.Drawing.Point( 83, 51 );
            this.btnShazam.Name = "btnShazam";
            this.btnShazam.Size = new System.Drawing.Size( 138, 33 );
            this.btnShazam.TabIndex = 6;
            this.btnShazam.Text = "Shazam";
            this.btnShazam.UseVisualStyleBackColor = true;
            this.btnShazam.Click += new System.EventHandler( this.btnShazam_Click );
            // 
            // txtLevel4
            // 
            this.txtLevel4.Location = new System.Drawing.Point( 21, 21 );
            this.txtLevel4.Name = "txtLevel4";
            this.txtLevel4.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel4.TabIndex = 5;
            this.txtLevel4.Text = "        Level 4         ";
            // 
            // txtLevel1
            // 
            this.txtLevel1.Location = new System.Drawing.Point( 19, 14 );
            this.txtLevel1.Name = "txtLevel1";
            this.txtLevel1.Size = new System.Drawing.Size( 95, 20 );
            this.txtLevel1.TabIndex = 6;
            this.txtLevel1.Text = "        Level 1         ";
            // 
            // FMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size( 422, 642 );
            this.Controls.Add( this.lblExtraCredit1 );
            this.Controls.Add( this.tabControl1 );
            this.Controls.Add( this.lblExtraCredit2 );
            this.Controls.Add( this.panLevel1 );
            this.Controls.Add( this.grbLevel2 );
            this.Controls.Add( this.txtLevel1 );
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Homework 13 - Trim All Form Textboxes";
            this.tabControl1.ResumeLayout( false );
            this.tabPage1.ResumeLayout( false );
            this.tabPage1.PerformLayout( );
            this.tabPage2.ResumeLayout( false );
            this.tabPage2.PerformLayout( );
            this.panLevel2.ResumeLayout( false );
            this.panLevel2.PerformLayout( );
            this.panLevel1.ResumeLayout( false );
            this.grbLevel2.ResumeLayout( false );
            this.grbLevel2.PerformLayout( );
            this.grbLevel3.ResumeLayout( false );
            this.grbLevel3.PerformLayout( );
            this.grbLevel4.ResumeLayout( false );
            this.grbLevel4.PerformLayout( );
            this.ResumeLayout( false );
            this.PerformLayout( );

        }

        #endregion

        private System.Windows.Forms.Label lblExtraCredit1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtLevel6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtLevel7;
        private System.Windows.Forms.TextBox txtLevel5;
        private System.Windows.Forms.Label lblExtraCredit2;
        private System.Windows.Forms.Panel panLevel2;
        private System.Windows.Forms.TextBox txtLevel2;
        private System.Windows.Forms.Panel panLevel1;
        private System.Windows.Forms.GroupBox grbLevel2;
        private System.Windows.Forms.GroupBox grbLevel3;
        private System.Windows.Forms.TextBox txtLevel3;
        private System.Windows.Forms.GroupBox grbLevel4;
        private System.Windows.Forms.Button btnShazam;
        private System.Windows.Forms.TextBox txtLevel4;
        private System.Windows.Forms.TextBox txtLevel1;
    }
}

